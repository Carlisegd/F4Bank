//
 
// ¯\_(ツ)_/¯

//

/*
Inspired by Alexis Doreau
AI Input - Listening & Thinking:
https://dribbble.com/shots/12006456-AI-Input-Listening-Thinking
*/